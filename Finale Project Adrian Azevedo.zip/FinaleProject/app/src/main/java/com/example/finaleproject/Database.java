package com.example.finaleproject;

// section dedicated to citations
//Cited 1
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/chapter/5/section/6-11

//Cited 2
// programmingKnoiowledge, 2015, Android SQLite Database Tutorial 1 # Introduction + Creating Database
// and Tables (Part 1), youtube,com
// :https://www.youtube.com/watch?v=cp2rL3sAFmI&list=PLS1QulWo1RIaRdy16cOzBO5Jr6kEagA07
// :https://www.youtube.com/watch?v=p8TaTgr4uKM&list=PLS1QulWo1RIaRdy16cOzBO5Jr6kEagA07&index=2





import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
public class Database extends SQLiteOpenHelper {

    // everything here is just the creation of the database
    // as such this file is paired witha  function file which contaisn all the database
    // functionality

    private static final String DATABASE_NAME = "userdb";
    private static final int VERSION = 2;

    public Database(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // USER TABLE
    public static class UserTable {
        public static final String TABLE = "users";
        public static final String USERID = "id";
        public static final String EMAIL = "email";
        public static final String USERNAME = "username";
        public static final String PASSWORD = "password";
    }

    // INVENTORY TABLE
    public static class InventoryTable {
        public static final String TABLE = "items";
        public static final String ITEMID = "id";
        public static final String ITEMNAME = "itemName";
        public static final String ITEMQUANTITY = "itemQuantity";
        public static final String ITEMDESC = "itemDesc";
    }

    @Override
    public void onCreate(SQLiteDatabase db){

        db.execSQL(
                "CREATE TABLE " + UserTable.TABLE + " (" +
                        UserTable.USERID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        UserTable.EMAIL + " TEXT, " +
                        UserTable.USERNAME + " TEXT UNIQUE, " +
                        UserTable.PASSWORD + " TEXT)"
        );

        db.execSQL(
                "CREATE TABLE " + InventoryTable.TABLE + " (" +
                        InventoryTable.ITEMID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        InventoryTable.ITEMNAME + " TEXT, " +
                        InventoryTable.ITEMQUANTITY + " INTEGER, " +
                        InventoryTable.ITEMDESC + " TEXT)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);

        onCreate(db); // ✅ only once
    }
}