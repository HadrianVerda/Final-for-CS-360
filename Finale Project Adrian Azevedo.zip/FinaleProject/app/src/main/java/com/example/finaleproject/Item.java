package com.example.finaleproject;

// section dedicated to citations
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/chapter/5/section/6-11
//Adrian Azevedo, 2025, assignment 4 java Security Class, SNHU.edu

public class Item {

    private int id;
    private String name;
    private String desc;
    private int quantity;
    private int imageResId;

    public Item(int id, String name, String desc, int quantity, int imageResId) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.quantity = quantity;
        this.imageResId = imageResId;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDesc() { return desc; }
    public int getQuantity() { return quantity; }
    public int getImageResId() { return imageResId; }
}