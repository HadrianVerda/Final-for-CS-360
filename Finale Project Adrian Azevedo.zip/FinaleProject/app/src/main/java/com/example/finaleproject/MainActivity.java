package com.example.finaleproject;
// section dedicated to citations
//Citation 1
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/chapter/2/section/1-11
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/chapter/4/section/10
//Citation 2
//Verify Beta, 2024, How to create a Custom Dialog box in Android Studio, youtube.com:
//https://www.youtube.com/watch?v=WSOmYN8y0_k
//
 //Citation 3
// Pavi_TechZone, 2024, how to Send Text Message in Android Studio | SMS Sending App in Android
// Studio | SMS Manager, youtube.com:https://www.youtube.com/watch?v=1BFj3MYrNuM

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    // This block contains the functional elements of the main activity
    RecyclerView recyclerView;
    ArrayList<Item> itemList;
    ItemAdapter adapter;
    Database_Function db;

    private static final int SMS_PERMISSION_CODE = 101; //SMS code

    @Override
    protected void onCreate(
            Bundle savedInstanceState
    )
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_three);

        db = new Database_Function(this);

        recyclerView = findViewById(R.id.recyclerView);
        itemList = new ArrayList<>();
        adapter = new ItemAdapter(itemList);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(adapter);

        // ✅ MUST be AFTER setContentView
        Button addButton = findViewById(R.id.buttonAdd);
        addButton.setOnClickListener(v -> showAddItemDialog());

        loadData();
    }
    // sets up the dialog box for item creation
    private void showAddItemDialog() {

        View view = getLayoutInflater().inflate(R.layout.activity_additem, null);

        EditText nameInput = view.findViewById(R.id.itemName);
        EditText qtyInput = view.findViewById(R.id.itemQuantity);
        EditText descInput = view.findViewById(R.id.itemDesc);

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(view)
                .setPositiveButton("Add", (dialog, which) -> {

                    String name = nameInput.getText().toString();
                    String desc = descInput.getText().toString();
                    int qty = Integer.parseInt(qtyInput.getText().toString());

                    db.addItem(name, qty, desc);
                    loadData(); // refresh RecyclerView
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    // loads the data from the inventory database
    private void loadData() {
        Cursor cursor = db.getAllItems();
        itemList.clear();

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(3),
                        cursor.getInt(2),
                        R.drawable.ic_launcher_round
                );
                itemList.add(item);

                // ✅ LOW INVENTORY CHECK HERE (correct place)
                if (item.getQuantity() < 5) {
                    checkSMSPermission();
                }

            } while (cursor.moveToNext());
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }
    // just cheks the permissions before sending message
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            sendSMS();
        }
    }

    private void sendSMS() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("1234567890", null,
                "low inventory!", null, null);
    }
    //requests permissiom
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    )
    {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSMS();
            }
        }
    }
}