package com.example.finaleproject;
// section dedicated to citations
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/
// Easy Tuto, 2024, Simple Login App in Android Studio | 2024, youtube.com
// :https://www.youtube.com/watch?v=H2potb8pGDQ

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText userNameLog, passwordLog;
    Button button, createAccountButton;
    Database_Function db;

    @Override
    // creation for login page
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); // ✅ should be login layout

        db = new Database_Function(this);

        userNameLog = findViewById(R.id.userNameLog);
        passwordLog = findViewById(R.id.passwordLog);
        button = findViewById(R.id.button);
        createAccountButton = findViewById(R.id.CreateAccountButton);

        // user login handler
        button.setOnClickListener(v -> {

            String username = userNameLog.getText().toString();
            String password = passwordLog.getText().toString();
            // empty prevention
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.loginUser(username, password)) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });

        // account creation  button
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
        });
    }
}