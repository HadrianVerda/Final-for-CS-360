package com.example.finaleproject;
// section dedicated to citations
//citation 3
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/chapter/5/section/6-11
//citation 2
//Adrian Azevedo, 2025, assignment 4 java Security Class, SNHU.edu
//citation 3
//Programming w/ Professor Sluiter, 2019, java Android App Tutorial Lists 02 ArrayList Adapter
// , youtube.com: https://www.youtube.com/watch?v=ylWz19SFCHg&list=TLPQMjcwNDIwMjbC6TPoygHtWA&index=2
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    ArrayList<Item> itemList;

    public ItemAdapter(ArrayList<Item> itemList) {
        this.itemList = itemList;
    }

    // View holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name, desc, qty;
        Button delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.itemImage);
            name = itemView.findViewById(R.id.itemName);
            desc = itemView.findViewById(R.id.itemDesc);
            qty = itemView.findViewById(R.id.itemQty);
            delete = itemView.findViewById(R.id.deleteBtn);
        }
    }

    //creation function
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout, parent, false);

        return new ViewHolder(view);
    }

    // this code organizes the items in the menu and retrieve the nessary information.
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Item item = itemList.get(position);

        holder.name.setText(item.getName());
        holder.desc.setText(item.getDesc());
        holder.qty.setText(String.valueOf(item.getQuantity()));
        holder.image.setImageResource(item.getImageResId());
        holder.delete.setOnClickListener(v -> {
            itemList.remove(position);
            notifyItemRemoved(position);
        });
    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }
}