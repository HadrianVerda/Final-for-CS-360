package com.example.finaleproject;
// section dedicated to citations
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1/
// Easy Tuto, 2024, Simple Login App in Android Studio | 2024, youtube.com
// :https://www.youtube.com/watch?v=H2potb8pGDQ
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText userNameLog, userNameLog2, passwordLog3;
    Button button;
    Database_Function db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation);

        db = new Database_Function(this);

        userNameLog = findViewById(R.id.userNameLog);   // username
        userNameLog2 = findViewById(R.id.userNameLog2); // email
        passwordLog3 = findViewById(R.id.passwordLog3); // password
        button = findViewById(R.id.button);
        // this code handles the  updating of the user database when a new account is made
         // it gathers the information makes sure its not null and then updates the database
        button.setOnClickListener(v -> {

            String username = userNameLog.getText().toString();
            String email = userNameLog2.getText().toString();
            String password = passwordLog3.getText().toString();

            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = db.registerUser(username, password, email);

            if (success) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
                finish(); // go back to login
            } else {
                Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
