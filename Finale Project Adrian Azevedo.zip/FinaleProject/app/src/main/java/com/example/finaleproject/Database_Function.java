package com.example.finaleproject;
// section dedicated to citations
//Cited 1
//https://learn.zybooks.com/zybook/CS-360-15332.202616-1

//Cited 2
// programmingKnoiowledge, 2015, Android SQLite Database Tutorial 1 # Introduction + Creating Database
// and Tables (Part 1), youtube,com
// :https://www.youtube.com/watch?v=cp2rL3sAFmI&list=PLS1QulWo1RIaRdy16cOzBO5Jr6kEagA07
// :https://www.youtube.com/watch?v=p8TaTgr4uKM&list=PLS1QulWo1RIaRdy16cOzBO5Jr6kEagA07&index=2
//:https://www.youtube.com/watch?v=PA4A9IesyCg&list=PLS1QulWo1RIaRdy16cOzBO5Jr6kEagA07&index=5


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Database_Function extends Database {
    public Database_Function(Context context) {
        super(context);
    }
    // USER FUNCTION
    //REGISTER NEW USER
    public boolean registerUser(
      String username,
      String password,
      String email
    )
    {
        if (username.isEmpty() || password.isEmpty() || email.isEmpty()) {
            return false;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(UserTable.USERNAME, username);
        values.put(UserTable.PASSWORD, password);
        values.put(UserTable.EMAIL, email);

        long result = db.insert(UserTable.TABLE, null, values);
        return result != -1;

    }
    //LOGIN USER
    public boolean loginUser(
            String username,
            String password
    )
    {
        if (username.isEmpty() || password.isEmpty()) {
            return false;
        }

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + UserTable.TABLE +
                        " WHERE " + UserTable.USERNAME + "=? AND " +
                        UserTable.PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // STORAGE SYSTEM FUNCTION
    // ADDS AN ITEM
    public void addItem(String name, int quantity, String desc) {
        if (name.isEmpty() || quantity < 0) {
            return;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.ITEMNAME, name);
        values.put(InventoryTable.ITEMQUANTITY, quantity);
        values.put(InventoryTable.ITEMDESC, desc);

        db.insert(InventoryTable.TABLE, null, values);
    }
    // RETRIEVES ALL ITEMS
    public Cursor getAllItems() {
        return getReadableDatabase().rawQuery(
                "SELECT * FROM " + InventoryTable.TABLE, null
        );
    }

    //  UPDATES AN ITEM
    public void updateItem(int id, String name, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(InventoryTable.ITEMNAME, name);
        values.put(InventoryTable.ITEMQUANTITY, quantity);

        db.update(
                InventoryTable.TABLE, values,
                InventoryTable.ITEMID + "=?",
                new String[]{String.valueOf(id)}
        );
    }
    //ITEM YEETER
    public void deleteItem(int id) {
        getWritableDatabase().delete(
                InventoryTable.TABLE,
                InventoryTable.ITEMID + "=?",
                new String[]{String.valueOf(id)}
        );
    }
}
